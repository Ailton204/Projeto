async function mostrarJogo() {
    const id = new URLSearchParams(window.location.search);
    const resposta = await fetch(`http://localhost:3000/produtos/${id}`);
    const jogo = await resposta.json();
    const container = document.getElementById("detalhes");

    container.innerHTML = `
        <div class="card mb-3" style="max-width: 540px;">
      <div class="row g-0">
        <div class="col-md-4">
          <img src="${jogo.src}" class="img-fluid rounded-start"  alt="...">
        </div>
        <div class="col-md-8">
          <div class="card-body">
            <h5 class="card-title">${jogo.titulo}</h5>
            <p class="card-text">${jogo.genero}</p>
            <p class="card-text"><small class="text-body-secondary">De ${jogo.preco} por apenas R$ 75,00 !</small></p>
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
              <button class="btn btn-primary" type="button">Adicionar ao Carrinho</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    `
}

mostrarJogo()