class Card extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {
    // const col = document.createElement("div");
    // col.className= "col-md-3 py-3 py-md-0";

    const card = document.createElement("div");
    card.className = "card mt-3";

    card.innerHTML = `
      <a href="contact.html?id=${this.getAttribute("id")}">
        <img src="${this.getAttribute(
          "src"
        )}" alt="${this.getAttribute("titulo")}">       
      </a>
      <div class="card-body">
          <h3 class="text-center">${this.getAttribute("titulo")}</h3>
          <p class="text-center">${this.getAttribute("genero")}</p>
          <div class="star text-center">
            <i class="fa-solid fa-star checked"></i>
            <i class="fa-solid fa-star checked"></i>
            <i class="fa-solid fa-star checked"></i>
            <i class="fa-solid fa-star checked"></i>
            <i class="fa-solid fa-star checked"></i>
        </div>
        <h2>${this.getAttribute(
          "preco"
        )} <span><li class="fa-solid fa-cart-shopping"></li></span></h2>
      </div>
    `;

    // col.appendChild(card)
    this.appendChild(card);
  }
}

customElements.define("card-item", Card);


fetch("http://localhost:3000/produtos")
  .then((res) => res.json())
  .then((json) => carregar(json))


function carregar(produtos) {
  const container = document.getElementById("cards-container");

  for (let i = 0; i < produtos.length; i++) {
    const produto = document.createElement("card-item");
    produto.className = "card"
    
    const img = document.createElement("img");
    img.src = produtos[i].src;
    img.alt = produtos[i].titulo;

    const titulo = document.createElement("h3");
    titulo.textContent = produtos[i].titulo;

    const genero = document.createElement("p");
    genero.textContent = produtos[i].genero;

    const preco = document.createElement("h2");
    preco.textContent = produtos[i].preco;

    produto.appendChild(img)
    produto.appendChild(titulo)
    produto.appendChild(genero)
    produto.appendChild(preco)

    container.appendChild(produto)
  }
}


